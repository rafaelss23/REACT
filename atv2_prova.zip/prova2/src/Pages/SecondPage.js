import * as React from 'react';
import {  Button, View, Text, StyleSheet} from 'react-native';

const Separator = () => <View style = {styles.Separator} />;

const SecondPage = ({ navigation }) => {
  return (
      <View style = {{ flex: 1, padding: 16, backgroundColor: "#FFC300"}}>
        <View
          style={{
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Text 
            style={{
              fontSize: 25, 
              textAlig: 'center', 
              marginBottom: 16,
            }}>
            </Text>
            <Button
              color="#E37D00"
              title='Ir para a "Primeira Tela"'
              onPress={() => navigation.navigate('FirstPage')} 
            />
            <Separator />
            <Button 
              color = "#37D00"
              title = 'Ir para a "Terceira Tela"'
              onPress={()=> navigation.navigate('ThirdPage')}
            />
          </View>
          <Text style={{ fontSize: 18, textAlign: 'center', color: '#730000'}}>
          </Text>

          <Text style={{ fontSize: 16, textAlign: 'center', color: '#730000'}}>
          </Text>
        </View>
  );
};

const styles=StyleSheet.create ({
    Separator: {
      marginVertical: 8,
      borderBottomColor: '#737373',
      borderBottomWidth: StyleSheet.hairlineWidth,
    },
});

export default SecondPage;