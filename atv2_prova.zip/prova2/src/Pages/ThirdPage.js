import * as React from 'react';
import {  Button, View, Text, StyleSheet} from 'react-native';

const Separator = () => <View style = {styles.Separator} />;

const ThirdPage = ({ navigation }) => {
  return (
      <View style = {{ flex: 1, padding: 16, backgroundColor: "#FFC300"}}>
        <View
          style={{
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Text 
            style={{
              fontSize: 25, 
              textAlig: 'center', 
              marginBottom: 16,
            }}>
            </Text>
            <Button
              color="#E37D00"
              onPress={() => navigation.navigate('FirstPage')} 
              title='Ir para a "Primeira Tela"'
              
            />
            <Separator />
            <Button 
              color = "#37D00"
              onPress={()=> navigation.navigate('SecondPage')}
              title = 'Ir para a "Segunda Tela"'
              
            />
          </View>
          <Text style={{ fontSize: 18, textAlign: 'center', color: '#730000'}}>
          </Text>

          <Text style={{ fontSize: 16, textAlign: 'center', color: '#730000'}}>
          </Text>
        </View>
  );
};

const styles=StyleSheet.create ({
    Separator: {
      marginVertical: 8,
      borderBottomColor: '#737373',
      borderBottomWidth: StyleSheet.hairlineWidth,
    },
});

export default ThirdPage;