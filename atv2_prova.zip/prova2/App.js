import * as React from 'react';
import { TouchableOpacity, View, Image } from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {StatusBar} from 'expo-status-bar';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigation} from '@react-navigation/drawer';

import firstPage from './src/Pages/firstPage';
import SecondPage from './src/Pages/SecondPage';
import ThirdPage from './src/Pages/ThirdPage';



import CustomSideBarMenu from './src/components/CustomSideBarMenu';

const Stack = createStackNavigator();
const Drawer = createDrawerNavigation ();


const StackIconHeaderLeft = (props) => {
  const toggleDrawer= () => {
    props.navigationProps.toggleDrawer();
  }


  return (
    <View style={{flexDirection: 'row'}}>
      <TouchableOpacity onPress={toggleDrawer}>
        <Image
        source= {require('./assets/icone.png')} style = {{width: 25, height: 25, marginLeft: 5 }}/>
      </TouchableOpacity>
    </View>
  );
}

function firstScreenStack({navigation}) { 
  return (
    <Stack.Screen
      name="FirstPage"
      component= {firstPage}
      options= {{
        title: 'Primeira tela',
        headerLeft: () => (<StackIconHeaderLeft navigationProps = {navigation} />),
        headerStyle: {backgroundColor: '#E37D00',},
        headerTintColor: '#FFFFF',
        headerTitleStyle: {fontWeight: 'bold',},
      }} />
  );
}

function secondScreenStack ({navigation}) {
  return (
    <Stack.Navigator 
      intialRouteName = "SecondPage"
      screenOptions = {{
        headerLeft: () => ( <StackIconHeaderLeft navigationProps={navigation}/> ),
        headerStyle: {backgroundColor: "#E37D00",}, 
        headerTintColor: '#FFFFFF',
        headerTitleStyle: { fontWeight: 'bold',},
      }}>
      <Stack.Screen
        name= "SecondPage"
        component = {SecondPage}
        options = {{title: 'Segunda tela',}}
      />
      <Stack.Screen
        name="ThirdPage"
        component={ThirdPage}
        options={{title: 'Terceira Tela'}}
      />
    </Stack.Navigator>
  );
}

export default function App () {
  return (
    <SafeAreaView style= {{flex: 1, backgroundColor: "#FEF3B4"}}>
      <StatusBar style = "light" backgroundColor = "#AD6200"/>
      <NavigationContainer>
        <Drawer.Navigator
          drawerContentOptions = {{
            activeTintColor: "#730000",
            inactiveTintColor: '#730000',
            itemStyle: {marginVertical: 5},
          }}
          drawerContent = {(props) => <CustomSideBarMenu {...props} /> } >
          <Drawer.Screen
            name = "firtsPage"
            options = {{ drawerLabel: 'Primeira Tela'}}
            component={firstScreenStack} />
          <Drawer.Screen
            name = "SecondPage"
            options = {{ drawerLabel: 'Segunda Tela'}}
            component={secondScreenStack} />
        </Drawer.Navigator>
      </NavigationContainer>
    </SafeAreaView>
  );
}