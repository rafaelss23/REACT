import * as React from 'react';
import { View, StyleSheet } from 'react-native';

const Separator = ({ marginVertical }) => <View style={{ marginVertical }} />;

export default Separator;
